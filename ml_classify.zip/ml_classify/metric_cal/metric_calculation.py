from sklearn import metrics
import numpy as np


# 指标计算
def Find_Optimal_Cutoff(TPR, FPR, threshold):
    y = TPR - FPR
    Youden_index = np.argmax(y)  # Only the first occurrence is returned.
    optimal_threshold = threshold[Youden_index]
    point = [FPR[Youden_index], TPR[Youden_index]]
    return optimal_threshold, point


def cal_fusion(label, pre):
    tn, fp, fn, tp = metrics.confusion_matrix(label, pre).ravel()
    acc = (float(tp) + float(tn)) / (float(tp) + float(fp) + float(fn) + float(tn))
    sen = float(tp) / (float(tp) + float(fn) + 1e-30)
    spe = float(tn) / (float(tn) + float(fp) + 1e-30)
    return acc, sen, spe


def claculate_index(Y_test, y_pro):
    y_pre_pro = y_pro[:, 1]
    pro_fpr, pro_tpr, pro_tho = metrics.roc_curve(Y_test, y_pre_pro)
    test_auc_pro = metrics.auc(pro_fpr, pro_tpr)

    optimal_th, optimal_point = Find_Optimal_Cutoff(TPR=pro_tpr, FPR=pro_fpr, threshold=pro_tho)

    temp = y_pre_pro.copy()
    for j in range(y_pre_pro.size):
        if y_pre_pro[j] >= optimal_th:
            temp[j] = 1
        else:
            temp[j] = 0
    t_acc, t_sen, t_spe = cal_fusion(Y_test, temp)
    pre_fdsfs = metrics.precision_score(Y_test, temp)
    sen = metrics.recall_score(Y_test, temp)
    # print("准确率为：{}, 灵敏度为：{}， 特异性为：{},auc:{}".format(t_acc, t_sen, t_spe, test_auc_pro))
    # toll[0] += t_acc
    # toll[1] += t_sen
    # toll[2] += t_spe
    # toll[3] += test_auc_pro
    return t_acc, t_sen, t_spe, test_auc_pro, pro_fpr, pro_tpr


def binary_classification_metrics(y_true, y_pred_prob):
    # 计算二分类AUC
    auc = metrics.roc_auc_score(y_true, y_pred_prob)

    # 将预测概率转换为类别预测
    y_pred_prob = np.array(y_pred_prob)
    y_pred = np.where(y_pred_prob > 0.5, 1, 0)

    # 计算准确率
    acc = metrics.accuracy_score(y_true, y_pred)

    # 计算混淆矩阵
    cm = metrics.confusion_matrix(y_true, y_pred)

    # 计算灵敏度和特异性
    sensitivity = cm[1, 1] / (cm[1, 1] + cm[1, 0])
    specificity = cm[0, 0] / (cm[0, 0] + cm[0, 1])

    # f1 = metrics.f1_score(y_true, y_pred)

    return auc, acc, sensitivity, specificity


def vessel_to_patient(y_true, y_pred_prob):
    y_true_patient, y_pred_prob_patient1, y_pred_prob_patient2 = [], [], []
    start_idx = 0

    while start_idx < len(y_true):
        if y_true[start_idx] == 0:
            num_data_per_patient = 3
            y_true_patient.append(0)
        else:
            num_data_per_patient = 5
            y_true_patient.append(1)

        tmp_pred = y_pred_prob[start_idx:start_idx + num_data_per_patient]
        # 方式1
        y_pred_prob_patient1.append(sum(tmp_pred) / len(tmp_pred))
        # 方式2
        y_pred_prob_patient2.append(max(tmp_pred))
        start_idx += num_data_per_patient

    return y_true_patient, y_pred_prob_patient1, y_pred_prob_patient2


# 计算病人级别的标签对应的性能指标，分别传入预测标签，真实标签，每个类别的病人对应的样本数量，每个类别病人的数量
def binary_classification_metrics_patient1(y_true, y_pred_prob):
    y_true_patient, y_pred_prob_patient1, y_pred_prob_patient2 = vessel_to_patient(y_true, y_pred_prob)
    auc, acc, sensitivity, specificity = binary_classification_metrics(y_true_patient, y_pred_prob_patient1)
    return auc, acc, sensitivity, specificity


def binary_classification_metrics_patient2(y_true, y_pred_prob):
    y_true_patient, y_pred_prob_patient1, y_pred_prob_patient2 = vessel_to_patient(y_true, y_pred_prob)
    auc, acc, sensitivity, specificity = binary_classification_metrics(y_true_patient, y_pred_prob_patient2)
    return auc, acc, sensitivity, specificity
