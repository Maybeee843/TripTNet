from scipy.io import loadmat
import numpy as np
import os


def load_data(parent_dir, test_index):
    data = []
    a = 0
    train_number_feature = []
    test_number_feature = []

    train_x_data = []
    train_y_data = []
    test_x_data = []
    test_y_data = []

    for i in range(108):
        parent_name = "patient%d" % (i + 1)
        patient_dir = os.path.join(parent_dir, parent_name)
        name_forder = os.listdir(patient_dir)
        num_feature = len(name_forder)
        if i in test_index:  # 获取每个病人特征的数量 确保标签和数量对应
            test_number_feature.append(num_feature)
            if i <= 30:
                test_y_data.append(1)
            else:
                test_y_data.append(0)
            # 获取测试数据
            for fi in range(num_feature):
                feature_name = "slice_%d" % (fi + 1)
                feature_path = os.path.join(patient_dir, feature_name)
                cur_data = loadmat(feature_path)
                cur_data = cur_data["data"]
                test_x_data.append(cur_data)
        else:
            train_number_feature.append(num_feature)
            if i <= 30:
                train_y_data.append(1)
            else:
                train_y_data.append(0)
            # 获取训练数据
            for fi in range(num_feature):
                feature_name = "slice_%d" % (fi + 1)
                feature_path = os.path.join(patient_dir, feature_name)
                cur_data = loadmat(feature_path)
                cur_data = cur_data["data"]
                train_x_data.append(cur_data)

    test_x_data = np.array(test_x_data).squeeze(1)
    train_x_data = np.array(train_x_data).squeeze(1)

    test_y_data = np.array(test_y_data)
    train_y_data = np.array(train_y_data)

    train_number_feature = np.array(train_number_feature)
    test_number_feature = np.array(test_number_feature)
    print("Done loading")

    return train_x_data, train_y_data, test_x_data, test_y_data, train_number_feature, test_number_feature


def load_data_ffr(num_fold, num_model=0, ensemble=True):  # ensemble表示是否进行Ensemble操作
    # train_dir = fr'D:\Dataset\301\augment_data\embedding\embedding_res_train_fold_{num_fold + 1}.npy'
    # test_dir = fr'D:\Dataset\301\augment_data\embedding\embedding_res_test_fold_{num_fold + 1}.npy'
    # val_dir = fr'D:\Dataset\301\augment_data\embedding\embedding_res_val_fold_{num_fold + 1}.npy'

    # train_dir = r'D:\Dataset\301\old_data_1\embedding\embedding_res_train.npy'
    # test_dir = r'D:\Dataset\301\old_data_1\embedding\embedding_res_val.npy'

    # train_dir = fr'D:\Dataset\301\augment_data\embedding_no_label\embedding_res_train_fold_{num_fold + 1}.npy'
    # test_dir = fr'D:\Dataset\301\augment_data\embedding_no_label\embedding_res_test_fold_{num_fold + 1}.npy'
    # val_dir = fr'D:\Dataset\301\augment_data\embedding_no_label\embedding_res_val_fold_{num_fold + 1}.npy'

    if ensemble:
        train_dir = fr'D:\Dataset\301\embedding_v2\ensemble\fold{num_fold}\embedding_res_train_{num_model}.npy'
        test_dir = fr'D:\Dataset\301\embedding_v2\ensemble\fold{num_fold}\embedding_res_test_{num_model}.npy'
        val_dir = fr'D:\Dataset\301\embedding_v2\ensemble\fold{num_fold}\embedding_res_val_{num_model}.npy'
    else:

        train_dir = fr'D:\Dataset\301\embedding_v2\last\fold{num_fold}\embedding_res_train_last.npy'
        test_dir = fr'D:\Dataset\301\embedding_v2\last\fold{num_fold}\embedding_res_test_last.npy'
        val_dir = fr'D:\Dataset\301\embedding_v2\last\fold{num_fold}\embedding_res_val_last.npy'

    # embedding_length = 4096
    embedding_length = 2048

    train_data = np.load(train_dir)
    test_data = np.load(test_dir)
    val_data = np.load(val_dir)

    train_x_data = np.array(train_data[:, :embedding_length])
    train_y_data = np.array(train_data[:, -1])
    print(train_x_data.shape, train_y_data.shape)

    test_x_data = np.array(test_data[:, :embedding_length])
    test_y_data = np.array(test_data[:, -1])
    print(test_x_data.shape, test_y_data.shape)

    val_x_data = np.array(val_data[:, :embedding_length])
    val_y_data = np.array(val_data[:, -1])
    print(val_x_data.shape, val_y_data.shape)

    # train_num_feature = np.ones((len(train_y_data)), dtype=np.int)
    # test_num_feature = np.ones((len(test_y_data)), dtype=np.int)
    # print(train_num_feature.shape, test_num_feature.shape)

    return train_x_data, train_y_data, test_x_data, test_y_data, val_x_data, val_y_data


def load_data_ffr_pre_train(num_fold, length=70, num_tuple=4):  # ensemble表示是否进行Ensemble操作

    embedding_root_dir = r'D:\Dataset\301\embedding'
    # train_dir = os.path.join(embedding_root_dir, fr'{length}\fold{num_fold}\embedding_res_train.npy')
    # test_dir = os.path.join(embedding_root_dir, fr'{length}\fold{num_fold}\embedding_res_test.npy')
    # val_dir = os.path.join(embedding_root_dir, fr'{length}\fold{num_fold}\embedding_res_val.npy')

    # train_dir = os.path.join(embedding_root_dir, fr'{length}\pair{num_tuple}\fold{num_fold}\embedding_res_train.npy')
    # test_dir = os.path.join(embedding_root_dir, fr'{length}\pair{num_tuple}\fold{num_fold}\embedding_res_test.npy')
    # val_dir = os.path.join(embedding_root_dir, fr'{length}\pair{num_tuple}\fold{num_fold}\embedding_res_val.npy')

    train_dir = os.path.join(embedding_root_dir, fr'{length}\no_augment\fold{num_fold}\embedding_res_train.npy')
    test_dir = os.path.join(embedding_root_dir, fr'{length}\no_augment\fold{num_fold}\embedding_res_test.npy')
    val_dir = os.path.join(embedding_root_dir, fr'{length}\no_augment\fold{num_fold}\embedding_res_val.npy')

    # embedding_length = 4096
    embedding_length = 2048
    if length == 90:
        embedding_length = 3072

    train_data = np.load(train_dir)
    test_data = np.load(test_dir)
    val_data = np.load(val_dir)

    train_x_data = np.array(train_data[:, :embedding_length])
    train_y_data = np.array(train_data[:, -1])
    print(train_x_data.shape, train_y_data.shape)

    test_x_data = np.array(test_data[:, :embedding_length])
    test_y_data = np.array(test_data[:, -1])
    print(test_x_data.shape, test_y_data.shape)

    val_x_data = np.array(val_data[:, :embedding_length])
    val_y_data = np.array(val_data[:, -1])
    print(val_x_data.shape, val_y_data.shape)

    # train_num_feature = np.ones((len(train_y_data)), dtype=np.int)
    # test_num_feature = np.ones((len(test_y_data)), dtype=np.int)
    # print(train_num_feature.shape, test_num_feature.shape)

    return train_x_data, train_y_data, test_x_data, test_y_data, val_x_data, val_y_data


def load_data_ffr_last(num_fold):  # ensemble表示是否进行Ensemble操作

    train_dir = fr'D:\Dataset\301\embedding_v2\last\fold{num_fold}\embedding_res_train_last.npy'
    test_dir = fr'D:\Dataset\301\embedding_v2\last\fold{num_fold}\embedding_res_test_last.npy'
    val_dir = fr'D:\Dataset\301\embedding_v2\last\fold{num_fold}\embedding_res_val_last.npy'

    # embedding_length = 4096
    embedding_length = 2048

    train_data = np.load(train_dir)
    test_data = np.load(test_dir)
    val_data = np.load(val_dir)

    train_x_data = np.array(train_data[:, :embedding_length])
    train_y_data = np.array(train_data[:, -1])
    print(train_x_data.shape, train_y_data.shape)

    test_x_data = np.array(test_data[:, :embedding_length])
    test_y_data = np.array(test_data[:, -1])
    print(test_x_data.shape, test_y_data.shape)

    val_x_data = np.array(val_data[:, :embedding_length])
    val_y_data = np.array(val_data[:, -1])
    print(val_x_data.shape, val_y_data.shape)

    # train_num_feature = np.ones((len(train_y_data)), dtype=np.int)
    # test_num_feature = np.ones((len(test_y_data)), dtype=np.int)
    # print(train_num_feature.shape, test_num_feature.shape)

    return train_x_data, train_y_data, test_x_data, test_y_data, val_x_data, val_y_data
