from xgboost import XGBClassifier
from sklearn import svm
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import AdaBoostClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn import metrics

def train_classify(X_train, Y_train, classifer):
    if classifer == "xgb":
        clf = XGBClassifier(learning_rate=0.1, n_estimators=1000, max_depth=7, min_child_weight=1, gamma=0, subsample=0.8,
                            seed=27, colsample_bytree=0.8, objective='binary:logistic', eval_metric='mlogloss')

    elif classifer == "svm":
        clf = svm.SVC(kernel='rbf', C=0.01, gamma='auto', probability=True)
    elif classifer == "knn":
        clf = KNeighborsClassifier(n_neighbors=29, leaf_size=40)
    elif classifer == "nb":
        clf = GaussianNB()
    elif classifer == "dt":
        clf = DecisionTreeClassifier(max_depth=20, min_samples_split=10)
    elif classifer == "ada":
        clf = AdaBoostClassifier(DecisionTreeClassifier(max_depth=20, min_samples_split=10),
                                 n_estimators=100, learning_rate=1)
    elif classifer == "rf":
        clf = RandomForestClassifier(n_estimators=200, max_depth=15)
        # clf = RandomForestClassifier(n_estimators=2, max_depth=1, min_samples_split=2, max_leaf_nodes=3, random_state=22)
    else:
        return
    clf.fit(X_train, Y_train.ravel())
    y_train_pre = clf.predict(X_train)

    tn, fp, fn, tp = metrics.confusion_matrix(Y_train, y_train_pre).ravel()
    train_acc = (float(tp)+float(tn)) / (float(tp)+float(fp)+float(fn)+float(tn))
    # y_pre = clf.predict(X_test)
    # y_pro = clf.predict_proba(X_test)
    return clf

