from sklearn.cluster import KMeans
import pandas as pd
import numpy as np


def K_means_Cluster(data, total_number_feature, num_clusters):
    # K_Means
    num_clusters = num_clusters
    estimator = KMeans(n_clusters=num_clusters)
    estimator.fit(data)
    pre = estimator.labels_
    # km_center = estimator.cluster_centers_               # 获取聚类中心
    begin = 0
    total_statistics = np.zeros((total_number_feature.__len__(), num_clusters))
    for ti in range(total_number_feature.__len__()):
        cur_num = total_number_feature[ti]              # 获取每个病人的总特征数
        cur_label = pre[begin:begin+cur_num]            # 获取每个病人每张特征的类别
        begin = begin + cur_num
        sacri = pd.value_counts(cur_label)              # 统计每类的数量
        for indexx in sacri.index:
            total_statistics[ti, indexx] = sacri[indexx]/cur_num        # 存储统计结果/归一化处理
    # print("Done processing")
    x = total_statistics
    return x, estimator

